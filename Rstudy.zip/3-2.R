# reshape2 패키지 설치하기(p.115)
install.packages("reshape2")


# 설치한 패키지 로드하기(p.118)
library(reshape2)


# 설치한 패키지 삭제하기(p.119)
remove.packages("reshape2")